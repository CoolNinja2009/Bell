'use strict';
/**
 * sync-profiles.js — Watches the root profiles.json (gitignored runtime state)
 * and copies it to defaults/profiles.json (tracked) whenever it changes.
 *
 * Usage:
 *   node sync-profiles.js       # run in foreground, Ctrl+C to stop
 *
 * Add to .gitignore so the script itself is never committed.
 */

const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const SRC = path.join(ROOT, 'profiles.json');
const DST = path.join(ROOT, 'defaults', 'profiles.json');

function log(msg) {
  console.log(`[${new Date().toISOString()}] ${msg}`);
}

function copy() {
  try {
    fs.copyFileSync(SRC, DST);
    const srcStat = fs.statSync(SRC);
    log(`copied (${srcStat.size} bytes)`);
  } catch (err) {
    console.error(`[${new Date().toISOString()}] copy failed: ${err.message}`);
  }
}

if (!fs.existsSync(SRC)) {
  console.error(`Source not found: ${SRC}`);
  process.exit(1);
}

// Initial copy
copy();

// Watch for changes
fs.watch(SRC, (eventType) => {
  if (eventType === 'change') {
    // Small debounce — fs.watch can fire twice on some editors
    clearTimeout(watchTimer);
    watchTimer = setTimeout(copy, 200);
  }
});

let watchTimer;

log(`watching ${SRC} → ${DST}`);
log('Press Ctrl+C to stop.');
